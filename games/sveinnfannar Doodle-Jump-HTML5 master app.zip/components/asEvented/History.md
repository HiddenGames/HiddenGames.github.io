0.4.1 / 2012-12-31
==================
* Bugfix: Fixed issues under >IE9 (@nazomikan)

0.4.0 / 2012-12-30
==================
* Feature: Added support for AMD and CommonJS (@KenPowers)

0.3.3 / 2012-07-06
==================
* Bugfix: fix global leak for num var (@travishorn)

0.3.2 / 2012-06-23
==================
* Feature: Added on/off aliases for bind/unbind

0.3.1 / 2012-03-22
==================
* Patch: More performance tweaks (@scarsick, @rk)

0.3.0 / 2012-03-19
==================
* Feature: Added one call (@mkuklis)
* Patch: Added support for the ONE-bound callbacks passing arguments to the event handler. (@rk)
* Feature: Added support for binding one callback to multiple events (@rk)

0.2.1 / 2012-03-15
==================
* Bugfix: All instances of a same 'class' are sharing the same events collection

0.2.0 / 2012-03-12
==================
* Bugfix: Gixing issues under Safari

0.1.0 / 2012-01-26
==================
* Bugfix: All callbacks were sharing the same 'events' object
